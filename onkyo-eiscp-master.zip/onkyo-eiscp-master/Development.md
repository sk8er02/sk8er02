Update the commands module
--------------------------

$ python generate_commands_module.py eiscp-commands.yaml > eiscp/commands.py
